<?php
$koneksi = mysqli_connect("localhost", "root", "", "rahmat_ukom");


?>